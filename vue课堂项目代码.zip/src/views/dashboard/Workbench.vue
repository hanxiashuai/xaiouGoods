<template>
  <div class="manu">工作台</div>
</template>

<script setup></script>

<style lang="scss" scoped>
.manu {
  height: 200vh;
}
</style>
