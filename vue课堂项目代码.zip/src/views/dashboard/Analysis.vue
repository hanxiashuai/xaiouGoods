<template>
  <div class="manu">分析页</div>
</template>

<script setup></script>

<style lang="scss" scoped>
.manu {
  height: 200vh;
}
</style>
