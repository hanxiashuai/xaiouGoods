<template>
  <div class="manu">管理员管理</div>
</template>

<script setup></script>

<style lang="scss" scoped>
.manu {
  height: 200vh;
}
</style>
