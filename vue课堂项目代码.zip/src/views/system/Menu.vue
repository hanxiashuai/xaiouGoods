<template>
  <div class="manu">
    <el-button type="primary" @click="open">打开</el-button>
  </div>
</template>

<script setup>
import { useMessage } from "@/hooks/useMessage";

const { ElMessage, ElMessageBox, ElNotification } = useMessage();

function open() {
  ElMessageBox.confirm("是否确认删除？", "警告", {
    confirmButtonText: "确认",
    cancelButtonText: "取消",
    type: "warning",
  })
    .then(() => {
      // 通知
      ElNotification({
        title: "通知",
        message: "删除成功",
      });
    })
    .catch(() => {
      ElMessage({
        type: "info",
        message: "Delete canceled",
      });
    });
}
</script>

<style lang="scss" scoped>
.manu {
  height: 800vh;
}
</style>
