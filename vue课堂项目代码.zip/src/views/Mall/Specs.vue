<template>
  <div class="manu">商品规格</div>
</template>

<script setup></script>

<style lang="scss" scoped>
.manu {
  height: 200vh;
}
</style>
