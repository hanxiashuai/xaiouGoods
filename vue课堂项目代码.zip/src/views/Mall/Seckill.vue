<template>
  <div class="manu">秒杀活动</div>
</template>

<script setup></script>

<style lang="scss" scoped>
.manu {
  height: 200vh;
}
</style>
