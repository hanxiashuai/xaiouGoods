<template>
  <!-- 匹配到的路由，页面会在这里展示 -->
  <router-view />
</template>

<style lang="scss">
* {
  margin: 0;
  padding: 0;
}

// 自定义进度条颜色
#nprogress .bar {
  background: #f811b2 !important; //自定义颜色
}
</style>
