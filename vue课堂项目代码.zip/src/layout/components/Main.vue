<template>
  <el-scrollbar>
    <div class="page_view">
      <!-- 页面切换加动画效果 -->
      <router-view v-slot="{ Component }">
        <transition
          name="fade-transform"
          mode="out-in"
          :duration="{ enter: 400, leave: 400 }"
          appear
        >
          <!-- 动态组件 -->
          <component :is="Component" />
        </transition>
      </router-view>
    </div>
    <!-- 回到顶部 -->
    <el-backtop target=".page_view" />
  </el-scrollbar>
</template>

<script setup></script>

<style lang="scss">
.page_view {
  padding: 12px;
  /* background-color: #eee; */
}

/* 修改滚动条颜色 */
.el-scrollbar__thumb {
  background: #046cfd;
}

/* fade-transform */
.fade-transform-leave-active,
.fade-transform-enter-active {
  transition: all 0.5s;
}

.fade-transform-enter-from {
  opacity: 0;
  transform: translateX(-30px);
}

.fade-transform-leave-to {
  opacity: 0;
  transform: translateX(30px);
}
</style>
