<template>
  <!-- 渲染单级菜单 -->
  <el-menu-item v-if="!hasChildren(data)" :index="data.url || data.id + ''">
    <el-icon v-if="data.icon">
      <!-- 动态组件 -->
      <component :is="handleMenuIconName(data.icon)"></component>
    </el-icon>
    <template #title>
      <span>{{ data.title }}</span>
    </template>
  </el-menu-item>

  <!-- 渲染多级菜单 -->
  <el-sub-menu v-else :index="data.url || data.id + ''">
    <template #title>
      <el-icon v-if="data.icon">
        <!-- 动态组件 -->
        <component :is="handleMenuIconName(data.icon)"></component>
      </el-icon>
      <span>{{ data.title }}</span>
    </template>

    <!-- 渲染多级菜单下面的子菜单，使用递归组件来解决 -->
    <template v-if="data.children">
      <MenuItem v-for="child in data.children" :key="child.id" :data="child" />
    </template>
  </el-sub-menu>
</template>

<script>
export default {
  // 递归组件一定要有name
  name: "MenuItem",
  props: {
    data: {
      type: Object,
      required: true,
      default: () => ({}),
    },
  },
  setup() {
    // 判断是否是单级菜单
    function hasChildren(item) {
      return item.children && item.children.length;
    }

    // 处理Icon图标的名字
    function handleMenuIconName(name) {
      return name.slice(8);
    }

    return {
      hasChildren,
      handleMenuIconName,
    };
  },
};
</script>

<style lang="scss" scoped></style>
