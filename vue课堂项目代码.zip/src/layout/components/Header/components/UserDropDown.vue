<template>
  <div class="userDropDown">
    <el-dropdown trigger="click" @command="handleCommand">
      <!-- 用户名 -->
      <span class="el-dropdown-link">
        admin
        <el-icon>
          <arrow-down />
        </el-icon>
      </span>

      <template #dropdown>
        <el-dropdown-menu>
          <el-dropdown-item icon="UserFilled" command="userInfo"
            >个人信息</el-dropdown-item
          >
          <el-dropdown-item icon="SwitchButton" divided command="logout"
            >退出登录</el-dropdown-item
          >
        </el-dropdown-menu>
      </template>
    </el-dropdown>
  </div>
</template>

<script setup>
import { useStore } from "vuex";
import { useRouter } from "vue-router";

const store = useStore();
const router = useRouter();

function handleCommand(val) {
  if (val === "logout") {
    // 退出登录
    store.commit("logout");
    router.replace("/login");
  } else if (val === "userInfo") {
    // 跳转到个人中心
  }
}
</script>

<style lang="scss" scoped>
@import "@/style/mixin.scss";

.userDropDown {
  cursor: pointer;
  width: 80px;
  height: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  align-items: center;

  &:hover {
    @include hover_bg_color;
  }

  .el-dropdown-link {
    display: flex;
    align-items: center;
  }
}
</style>
