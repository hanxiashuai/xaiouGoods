<template>
  <div class="themeToggle" @click="changeTheme">
    <el-tooltip
      effect="dark"
      :content="isDark ? '默认主题' : '暗黑主题'"
      placement="bottom"
    >
      <el-icon>
        <component :is="isDark ? 'Sunny' : 'MoonNight'"></component>
      </el-icon>
    </el-tooltip>
  </div>
</template>

<script setup>
import { useStore } from "vuex";
import { useDark, useToggle } from "@vueuse/core";

const store = useStore();

const isDark = useDark({
  selector: "html",
  attribute: "class",
  valueDark: "dark",
  valueLight: "light",
});

function changeTheme() {
  const toggleDark = useToggle(isDark);
  const res = toggleDark();
  console.log(res);
  store.commit("setIsDark", res);
}
</script>

<style lang="scss" scoped>
@import "@/style/mixin.scss";

.themeToggle {
  cursor: pointer;
  width: 38px;
  height: 100%;
  padding: 0 10px;
  box-sizing: border-box;
  display: flex;
  justify-content: center;
  align-items: center;

  &:hover {
    /* 不能写死这个背景颜色 */
    /* background-color: #f6f6f6; */
    /* 使用scss的混入，让这个背景颜色自动随系统主题变化 */
    @include hover_bg_color;
  }
}

/* 暗黑主题生效的样式 */
/* html[class="dark"] .themeToggle:hover {
  background-color: #242424;
} */
</style>
