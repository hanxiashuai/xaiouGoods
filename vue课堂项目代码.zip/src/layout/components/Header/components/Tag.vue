<template>
  <el-scrollbar>
    <div class="scrollbar-flex-content">
      <el-tag
        v-for="(item, index) in tags"
        :key="item.path"
        :style="{ marginLeft: index ? '5px' : '0px' }"
        :closable="!!index"
        :effect="activePath == item.path ? 'dark' : 'plain'"
        @click="goPage(item.path)"
        @close="handleClose(index)"
        >{{ item.name }}</el-tag
      >
    </div>
  </el-scrollbar>
</template>

<script setup>
import { reactive, watch, ref } from "vue";
import { useRoute, useRouter } from "vue-router";

const tags = reactive([]);
// 当前激活的路由
const activePath = ref("");

const route = useRoute();
const router = useRouter();

watch(
  () => route,
  (to) => {
    activePath.value = to.fullPath;

    // 判断 tags 是否存在 tag
    const hasTag = tags.find((item) => item.path === to.fullPath);
    if (!hasTag) {
      tags.push({
        name: to.meta.title,
        path: to.fullPath,
      });
    }
  },
  {
    deep: true,
    immediate: true,
  }
);

// 点击tag跳转路由
function goPage(path) {
  router.push(path);
}

// 关闭tag
function handleClose(idx) {
  tags.splice(idx, 1);
  router.push(tags[idx - 1].path);
}
</script>

<style lang="scss" scoped>
.el-tag {
  cursor: pointer;
}

.scrollbar-flex-content {
  display: flex;
}
</style>
