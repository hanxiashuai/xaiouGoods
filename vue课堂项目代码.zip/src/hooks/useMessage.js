import { ElMessage, ElMessageBox, ElNotification } from "element-plus";

export function useMessage() {
  return {
    ElMessage,
    ElMessageBox,
    ElNotification,
  };
}
