export default [
  {
    path: "/analysis",
    name: "analysis",
    meta: {
      title: "分析页",
      breadcrumb: ["Dashboart", "分析页"],
    },
    component: () =>
      import(
        /* webpackChunkName: "Analysis" */ "@/views/dashboard/Analysis.vue"
      ),
  },
  {
    path: "/workbench",
    name: "workbench",
    meta: {
      title: "工作台",
      breadcrumb: ["Dashboart", "工作台"],
    },
    component: () =>
      import(
        /* webpackChunkName: "Workbench" */ "@/views/dashboard/Workbench.vue"
      ),
  },
];
