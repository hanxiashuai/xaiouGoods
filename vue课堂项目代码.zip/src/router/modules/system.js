// 配置系统设置相关的路由
export default [
  {
    path: "/menu",
    name: "menu",
    // 我们程序员可以给路由添加一些自定义的属性，可以使用 meta 元数据
    meta: {
      title: "菜单管理",
      breadcrumb: ["系统设置", "菜单管理"],
    },
    component: () =>
      import(/* webpackChunkName: "Menu" */ "@/views/system/Menu.vue"),
  },
  {
    path: "/role",
    name: "role",
    meta: {
      title: "角色管理",
      breadcrumb: ["系统设置", "角色管理"],
    },
    component: () =>
      import(/* webpackChunkName: "Role" */ "@/views/system/Role.vue"),
  },
  {
    path: "/admin",
    name: "admin",
    meta: {
      title: "管理员管理",
      breadcrumb: ["系统设置", "管理员管理"],
    },
    component: () =>
      import(/* webpackChunkName: "Admin" */ "@/views/system/Admin.vue"),
  },
];
