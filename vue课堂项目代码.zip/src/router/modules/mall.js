// 配置商城管理相关的权限路由
export default [
  {
    path: "/category",
    name: "category",
    meta: {
      title: "商品分类",
      breadcrumb: ["商城管理", "商品分类"],
    },
    component: () =>
      import(/* webpackChunkName: "Category" */ "@/views/Mall/Category.vue"),
  },
  {
    path: "/specs",
    name: "specs",
    meta: {
      title: "商品规格",
      breadcrumb: ["商城管理", "商品规格"],
    },
    component: () =>
      import(/* webpackChunkName: "Specs" */ "@/views/Mall/Specs.vue"),
  },
  {
    path: "/goods",
    name: "goods",
    meta: {
      title: "商品管理",
      breadcrumb: ["商城管理", "商品管理"],
    },
    component: () =>
      import(/* webpackChunkName: "Goods" */ "@/views/Mall/Goods.vue"),
  },
  {
    path: "/member",
    name: "member",
    meta: {
      title: "会员管理",
      breadcrumb: ["商城管理", "会员管理"],
    },
    component: () =>
      import(/* webpackChunkName: "Member" */ "@/views/Mall/Member.vue"),
  },
  {
    path: "/banner",
    name: "banner",
    meta: {
      title: "轮播图管理",
      breadcrumb: ["商城管理", "轮播图管理"],
    },
    component: () =>
      import(/* webpackChunkName: "Banner" */ "@/views/Mall/Banner.vue"),
  },
  {
    path: "/seckill",
    name: "seckill",
    meta: {
      title: "秒杀活动",
      breadcrumb: ["商城管理", "秒杀活动"],
    },
    component: () =>
      import(/* webpackChunkName: "Seckill" */ "@/views/Mall/Seckill.vue"),
  },
];
