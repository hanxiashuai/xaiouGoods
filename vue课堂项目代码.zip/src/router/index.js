import { createRouter, createWebHistory } from "vue-router";
import store from "@/store";
// 导入进度条插件
import useNProgress from "@/hooks/useNProgress";
const NProgress = useNProgress();

// 布局组件
const Layout = () =>
  import(/* webpackChunkName: "layout" */ "@/layout/index.vue");

// 对于权限管理，刚开始路由只加载，不需要权限的路由，比如：登录、404，这些无关紧要的路由
// 对于这些需要权限的路由，我们需要根据后台返回的权限路由，通过router.addRoute()动态添加进来
const routes = [
  {
    path: "/login",
    name: "login",
    // 路由懒加载
    component: () =>
      import(/* webpackChunkName: "login" */ "../views/Login.vue"),
  },
  {
    path: "/",
    name: "layout",
    // 路由懒加载
    component: Layout,
    children: [],
  },
  // 404路由
  {
    path: "/:pathMatch(.*)*",
    name: "notFound",
    component: () =>
      import(/* webpackChunkName: "notFound" */ "@/views/NotFound.vue"),
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

// 导航前置守卫
router.beforeEach((to, from, next) => {
  // 开启进度条
  NProgress.start();

  const token = store.state.userStore.token;
  if (to.name !== "login") {
    if (!token) {
      // 返回到登录页
      next({ name: "login" });
    } else {
      // 说明用户登录过了
      // 判断当前用户是否加载权限路由了，如果没有加载权限路由，则重新加载
      if (!store.state.userStore.alreadyLoadAsyncRoutes) {
        store.dispatch("addAsyncRoute");
        router.push(to.fullPath);
      }
      next();
    }
  } else {
    next();
  }
});

// 导航后置守卫
router.afterEach(() => {
  // 关闭进度条
  NProgress.done();
});

export default router;
