import axios from "axios";
import store from "@/store";

import { useMessage } from "@/hooks/useMessage";
const ElMessage = useMessage();

const service = axios.create({
  // 根据项目所处的环境，自动来加载所需的url地址
  baseURL: process.env.VUE_APP_URL,
  // 请求超时时间
  timeout: 1000 * 60 * 5,
});

// 请求拦截器
service.interceptors.request.use(
  (config) => {
    const token = store.state.userStore.token;
    // 请求携带token字段
    if (token && !config.url.includes("userlogin")) {
      config.header[process.env.VUE_APP_AJAX_HEADER_AUTH_NAME] = token;
    }
    // 一定要把处理好的config返回出去
    return config;
  },
  (err) => Promise.reject(err)
);

// 响应拦截器
service.interceptors.response.use(
  (response) => {
    // console.log("response：", response);
    // 如果code不是200,就是失败了
    if (response.data.code !== 200) {
      ElMessage({
        showClose: true,
        message: response.data.msg,
        type: "error",
      });
      return Promise.reject(response.data.msg);
    } else {
      return response.data;
    }
  },
  (err) => Promise.reject(err)
);

export default service;
