export default {
  changeLangSuccess: "言葉の切り替えに成功する",
};
