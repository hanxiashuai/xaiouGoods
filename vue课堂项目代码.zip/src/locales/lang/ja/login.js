export default {
  signIn: "ログイン",
  userError: "ユーザー名を入力してください",
  userPlaceholder: "ユーザー名を入力してください",
  PWError: "パスワードを入力してください",
  passPlaceholder: "パスワードを入力してください",
  PWSubError: "パスワードは3桁以上のアルファベットまたは数字",
  captchaError: "認証コードをクリックしてチェックしてください",
  signInSuccess: "ログインに成功する",
};
