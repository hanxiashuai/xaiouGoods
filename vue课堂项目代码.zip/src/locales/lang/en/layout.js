export default {
  changeLangSuccess: "Language switch succeeded",
};
