export default {
  changeLangSuccess: "语言切换成功",
};
