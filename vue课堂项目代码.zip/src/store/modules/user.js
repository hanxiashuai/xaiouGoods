// 用户相关的store
import { login } from "@/api/user";
import router from "@/router";

export default {
  state: {
    token: localStorage.getItem(process.env.VUE_APP_TOKEN_NAME) || "",
    userInfo:
      JSON.parse(localStorage.getItem(process.env.VUE_APP_USER_INFO)) || {},
    // 标识下用户是否加载过动态路由了
    alreadyLoadAsyncRoutes: false,
  },
  mutations: {
    updateToken(state, token) {
      state.token = token;
      // 把token保存到localStorage
      localStorage.setItem(process.env.VUE_APP_TOKEN_NAME, token);
    },
    updateUserInfo(state, userInfoObj) {
      state.userInfo = userInfoObj;
      // 把token保存到localStorage
      localStorage.setItem(
        process.env.VUE_APP_USER_INFO,
        JSON.stringify(userInfoObj)
      );
    },
    updateLoadAsyncRoutes(state) {
      state.alreadyLoadAsyncRoutes = true;
    },
    // 处理退出登录
    logout(state) {
      state.token = "";
      state.userInfo = null;
      localStorage.removeItem(process.env.VUE_APP_TOKEN_NAME);
      localStorage.removeItem(process.env.VUE_APP_USER_INFO);
    },
  },
  actions: {
    // 处理登录
    async loginAction({ commit, dispatch }, data) {
      try {
        // 发送登录的网络请求
        const res = await login(data);
        // 登录成功，保存相关的数据
        commit("updateToken", res.list.token);
        commit("updateUserInfo", {
          menus: res.list.menus,
          menus_url: res.list.menus_url,
          username: res.list.username,
        });
        // 处理了权限路由
        dispatch("addAsyncRoute");
        return true;
      } catch (error) {
        return Promise.reject(error);
      }
    },
    // 加载权限路由，动态添加到系统中
    addAsyncRoute({ state, commit }) {
      // 保存系统中所有的权限路由
      const allRoutes = [];
      // 递归获取router/modules目录下的所有以.js文件结尾的暴露出来的模块
      const routeFiles = require.context("@/router/modules", true, /\.js/);
      routeFiles.keys().forEach((item) => {
        const routes = require("@/router/modules" + item.split(".")[1]);
        allRoutes.push(...routes.default);
      });

      // console.log("所有的权限路由：", allRoutes);

      // 获取后台返回的路由列表
      const backRoutes = state.userInfo.menus_url;
      // console.log("后台返回的路由列表", backRoutes);

      // 比对筛选出权限路由
      const asyncRoutes = allRoutes.filter((item) =>
        backRoutes.includes(item.path)
      );

      // console.log("筛选后的权限路由：", asyncRoutes);

      // 将筛选后的权限路由添加到系统中
      asyncRoutes.forEach((route) => {
        // 将权限路由，添加到 layout 的子路由中
        router.addRoute("layout", route);
      });

      // 标识该用户已经加载过权限路由了
      commit("updateLoadAsyncRoutes");
    },
  },
};
